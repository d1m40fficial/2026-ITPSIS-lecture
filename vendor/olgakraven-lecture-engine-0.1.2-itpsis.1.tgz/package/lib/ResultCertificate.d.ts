import type { Course, Lecture } from './model';
import type { AccessFile } from './access';
export declare function ResultCertificate({ course, base, lecture, access, codeHash, result }: {
    course: Course;
    base: string;
    lecture: Lecture;
    access: AccessFile;
    codeHash: string;
    result: {
        score: number;
        total: number;
        correct: number;
        wrong: number;
    };
}): import("react").JSX.Element;
